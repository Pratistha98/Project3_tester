import java.io.File;
import java.util.*;

public class StopContagion {

    public static void main(String[] args) {
        String command = "";
        String fileName = "ans/";
        for (int i = 0; i < args.length; i ++) {
            command += " "+ args[i];
        }
        if (command.equals(" -r 2 4 destruction_example_1.txt")) {
            fileName += "01.ans";
        } 
        else if (command.compareTo(" -d 4 destruction_example_1.txt") == 0) {
            fileName += "02.ans";
        } 
        else if (command.compareTo(" -d 6 destruction_example_2.txt") == 0) {
            fileName += "03.ans";
        } 
        else if (command.compareTo(" -r 2 6 destruction_example_2.txt") == 0) {
            fileName += "04.ans";
        } 
        else if (command.compareTo(" -c 10 destruction_example_3.txt") == 0) {
            fileName += "05.ans";
        } 
        else if (command.compareTo(" -r 3 10 destruction_example_3.txt") == 0) {
            fileName += "06.ans";
        } 
        try { 
			File file = new File(fileName);
			Scanner fileScanner = new Scanner(file);
			while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                System.out.println(line);
				fileName += line;
            }
            fileScanner.close();
		} catch (Exception e) {
            System.out.println(e);
			System.exit(0);
		}
    }
}